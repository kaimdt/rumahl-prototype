<?php
return [
  "db" => ["host" => "127.0.0.1", "port" => 3307, "name" => "rumahl_status", "user" => "rumahl_status", "pass" => "testpass123"],
  "admin_token" => "test-admin-token-123456",
  "cron_key" => "test-cron-key-123456",
];
